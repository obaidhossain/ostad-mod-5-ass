<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Our Crew Project</title>
  </head>
  <body>
    <div class="container">
      <h2>Our Crew Project</h2>
      <p><a href="./login.php">Login</a></p>
      <p><a href="./registration.php">Registration</a></p>
    </div>
  </body>
</html>
